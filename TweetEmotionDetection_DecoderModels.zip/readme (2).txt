This repository contains notebooks and code for a multilabel text classification project using decoder-based models. The project explores three approaches: fine-tuning a decoder with a classification head, using a language modeling head, and leveraging instruction-tuned decoder models for label generation.

Part A: Decoder Base Model with Classification Head
Approach:
Adds a classification layer on top of a decoder model.
Predicts each label independently (binary yes/no).
It is simple, effective, works well with fully labeled datasets.

Part B: Decoder Base Model with Language Head
Objective: Fine-tune a decoder-based model using the language modeling head, treating classification as text generation.
Uses the decoder’s natural text generation to produce labels as text.
Constrained decoding ensures only valid labels are output.
Captures relationships between labels better than independent binary predictions.

Part C: Decoder Instruction Model with Language Head
Objective: Fine-tune an instruction-tuned decoder model using the language head to generate labels.
Fine-tunes an instruction-following model to generate labels from prompts.
Can handle flexible label combinations and new tasks more easily.
Uses constrained decoding to maintain accuracy and consistency.

https://wandb.ai/jahnavi-13489-1/multilabel_stack_2025
